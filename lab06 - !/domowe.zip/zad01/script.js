let totalValue = 0;
let active = true;
let increment = true;

function handleClick(value, color) {
    if (!active) return;

    if (increment) {
        totalValue += value;
    } else {
        totalValue -= value;
    }

    showMessage(`You clicked ${color} button: ${value}`);

    if (totalValue >= 30) {
        disableButton('button3');
    }

    if (totalValue >= 50) {
        disableButton('button2');
    }
}

function propagationOnOff() {
    active = !active;

    const propagation = document.getElementById('propagationOnOff');
    propagation.textContent = active ? 'Propagation: ON' : 'Propagation: OFF';
}

function reset() {
    totalValue = 0;
    showMessage('Click a button to start');
    enableButton('button1');
    enableButton('button2');
    enableButton('button3');
}

function propagationDirection() {
    increment = !increment;

    const incrementButton = document.getElementById('propagationDirection');
    incrementButton.textContent = increment ? 'Propagation Increment' : 'Propagation Decrement';
}


function disableButton(buttonId) {
    const button = document.getElementById(buttonId);
    button.removeEventListener('click', handleClick);
    button.style.pointerEvents = 'none';        // Wyłącza interakcję z divem
    button.style.opacity = '0.5';               // Ustawienie przezroczystości na 50%
    button.style.filter = 'grayscale(100%)';    // Zastosowanie efektu odbarwienia
}

function enableButton(buttonId) {
    const button = document.getElementById(buttonId);
    button.addEventListener('click', handleClick);
    button.style.pointerEvents = 'auto';        // Włącza interakcję z divem
    button.style.opacity = '1';                 // Ustawienie przezroczystości na 100%
    button.style.filter = 'grayscale(0%)';      // Zastosowanie efektu odbarwienia
}


function showMessage(message) {
    const messageElement = document.getElementById('message');
    const scoreElement = document.getElementById('score');
    messageElement.textContent = message;
    scoreElement.textContent = totalValue;
}
